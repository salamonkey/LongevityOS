import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import {
  SLICE_LIST_FIELDS,
  readText,
  writeTextAtomic,
  loadManifest,
  loadValues,
  initValuesFile,
  verifyRequiredTokens,
  verifyTemplateTokens,
  verifyTemplateTokensForEntries,
  expectedContent,
  upsertPackageScripts,
  ensurePackageJson,
  isGeneratedFile,
  writeEntries,
  assertApprovedBrief,
  assertMinimumCustomerInput,
  parseEnvKeys,
  parseBlockScalars,
  parseStatusBlock,
  parseBacklogSlices,
  parseSliceBlock,
  parseSliceBlockWithLists,
  parseBacklogSliceStatus,
  parseSectionListValues,
  listAllPlaceholderMatches,
  normalizeWhitespace,
  quoteYamlString,
  metadataHeader,
  setSectionScalar,
  setTopLevelScalar,
  stripGeneratedAt,
  firstDiffLine,
  ensureDir,
  isBootstrapInitialization,
  getBootstrapReviewRelPaths,
  loadValuesIfPresent,
} from '../lib/core.mjs';

function initFactory({ targetRoot, valuesPath, force, initValues, forceValues }) {
  if (initValues) {
    initValuesFile(valuesPath, forceValues);
  }
  const manifest = loadManifest();
  const entries = manifest.factory_init_source_of_truth || [];
  const outputs = writeEntries({
    targetRoot,
    valuesPath,
    force,
    entries,
    checkBriefApproval: false,
  });

  console.log(`fabric init-factory: generated ${outputs.length} files`);
  outputs.forEach((item) => console.log(`- ${item}`));
}

function formatFromBrief({ targetRoot }) {
  assertApprovedBrief(targetRoot);
  assertMinimumCustomerInput(targetRoot);
  console.log('fabric format-from-brief: brief is approved, execution can proceed');
}

function instantiate({ targetRoot, valuesPath, force }) {
  const manifest = loadManifest();
  const values = loadValues(valuesPath);
  verifyRequiredTokens(manifest, values);
  verifyTemplateTokens(manifest, values);

  const outputs = writeEntries({
    targetRoot,
    valuesPath,
    force,
    entries: manifest.source_of_truth || [],
    checkBriefApproval: isBootstrapInitialization(targetRoot),
  });

  console.log(`fabric instantiate: generated ${outputs.length} files`);
  outputs.forEach((item) => console.log(`- ${item}`));
}

function execute({ targetRoot, valuesPath, force }) {
  instantiate({ targetRoot, valuesPath, force });
}

function hasSupabaseCli() {
  const res = spawnSync('supabase', ['--version'], { encoding: 'utf8' });
  return res.status === 0;
}

function dbCheck({ targetRoot }) {
  const manifest = loadManifest();
  const issues = [];
  const dbConfig = manifest.db || {};

  for (const rel of dbConfig.required_files || []) {
    if (!fs.existsSync(path.join(targetRoot, rel))) {
      issues.push(`missing required DB file: ${rel}`);
    }
  }

  const envKeys = parseEnvKeys(path.join(targetRoot, '.env.example'));
  for (const key of dbConfig.required_env_keys || []) {
    if (!envKeys.has(key)) {
      issues.push(`missing required env key in .env.example: ${key}`);
    }
  }

  const pkgPath = path.join(targetRoot, 'package.json');
  if (fs.existsSync(pkgPath)) {
    const pkg = JSON.parse(readText(pkgPath));
    for (const [name, command] of Object.entries(dbConfig.required_package_scripts || {})) {
      if (!pkg?.scripts || pkg.scripts[name] !== command) {
        issues.push(`missing/incorrect package script ${name}`);
      }
    }
  }

  if (!hasSupabaseCli()) {
    issues.push('supabase CLI not available in PATH');
  }

  if (issues.length > 0) {
    console.error('fabric db:check: FAILED');
    issues.forEach((i) => console.error(`- ${i}`));
    process.exit(1);
  }

  console.log('fabric db:check: OK');
}

function runShellCommand(command, cwd) {
  const res = spawnSync(command, {
    cwd,
    shell: true,
    stdio: 'inherit',
    encoding: 'utf8',
  });
  if (res.status !== 0) {
    process.exit(res.status || 1);
  }
}

function dbReset({ targetRoot, yes }) {
  const manifest = loadManifest();
  if (!yes) {
    throw new Error('db:reset requires --yes (destructive operation)');
  }
  const command = manifest?.db?.reset_command || 'supabase db reset';
  console.log(`fabric db:reset: executing '${command}'`);
  runShellCommand(command, targetRoot);
}

function dbSeed({ targetRoot, yes }) {
  const manifest = loadManifest();
  const seedPath = path.join(targetRoot, 'supabase/seed.sql');
  if (!fs.existsSync(seedPath)) {
    throw new Error('Cannot run db:seed: missing supabase/seed.sql');
  }
  const command = manifest?.db?.seed_command || 'supabase db reset';
  if (/\breset\b/i.test(command) && !yes) {
    throw new Error("db:seed requires --yes when seed_command includes 'reset' (destructive operation)");
  }
  console.log(`fabric db:seed: executing '${command}'`);
  runShellCommand(command, targetRoot);
}

function dbInit({ targetRoot, valuesPath, force }) {
  const manifest = loadManifest();
  const values = loadValues(valuesPath);
  verifyRequiredTokens(manifest, values);
  verifyTemplateTokens(manifest, values);

  const generatedAt = new Date().toISOString();
  const targets = [
    { source: 'db/supabase-config.template.toml', target: 'supabase/config.toml' },
    { source: 'db/supabase-seed.template.sql', target: 'supabase/seed.sql' },
    { source: 'templates/env-example.template', target: '.env.example' },
  ];

  for (const item of targets) {
    const outPath = path.join(targetRoot, item.target);
    if (fs.existsSync(outPath) && !force) {
      const existing = readText(outPath);
      if (!isGeneratedFile(existing)) {
        throw new Error(`Refusing to overwrite non-generated file without --force: ${item.target}`);
      }
    }
    const entry = { source: item.source, target: item.target };
    const output = expectedContent(entry, manifest, values, generatedAt);
    ensureDir(outPath);
    fs.writeFileSync(outPath, output, 'utf8');
  }

  const packageJsonPath = path.join(targetRoot, 'package.json');
  const createdPackageJson = ensurePackageJson(packageJsonPath, values);
  upsertPackageScripts(packageJsonPath, manifest?.db?.required_package_scripts || {});

  if (createdPackageJson) {
    console.log('fabric db:init: created minimal package.json');
  }
  console.log('fabric db:init: OK');
}

function sliceReadinessListsPresent(slice) {
  return [...SLICE_LIST_FIELDS].every((field) => Array.isArray(slice[field]) && slice[field].length > 0);
}

function sliceHasPlaceholderValues(slice) {
  const values = [];
  for (const key of ['id', 'title', 'objective', 'milestone', 'status']) {
    if (slice[key] != null) {
      values.push(String(slice[key]));
    }
  }
  for (const field of SLICE_LIST_FIELDS) {
    for (const item of slice[field] || []) {
      values.push(String(item));
    }
  }
  return listAllPlaceholderMatches(values.join('\n')).length > 0;
}

function collectBootstrapSemanticIssues({
  targetRoot,
  valuesPath,
  manifestText,
  currentSliceText,
  backlogText,
}) {
  const issues = [];
  const operatingModel = parseBlockScalars(manifestText, 'operating_model');
  const currentMode = String(operatingModel.current_mode || '').toLowerCase();
  const approvedReviews = parseSectionListValues(manifestText, 'status', 'approved_reviews');

  if (currentMode === 'delivery' && approvedReviews.length === 0) {
    issues.push('delivery mode set but status.approved_reviews is empty; run pm:bootstrap-signoff');
  }

  const values = loadValuesIfPresent(valuesPath);
  const reviewRelPaths = Object.values(getBootstrapReviewRelPaths(values));
  const semanticFiles = [
    { relPath: 'docs/product/backlog.yaml', content: backlogText },
    { relPath: 'docs/product/current-slice.yaml', content: currentSliceText },
  ];
  for (const relPath of reviewRelPaths) {
    const absPath = path.join(targetRoot, relPath);
    if (!fs.existsSync(absPath)) {
      if (currentMode === 'delivery') {
        issues.push(`delivery mode set but missing bootstrap review file: ${relPath}`);
      }
      continue;
    }
    semanticFiles.push({ relPath, content: readText(absPath) });
  }

  for (const file of semanticFiles) {
    const placeholders = listAllPlaceholderMatches(file.content);
    if (placeholders.length > 0) {
      issues.push(`${file.relPath}: unresolved placeholders detected (${[...new Set(placeholders)].join(', ')})`);
    }
  }

  const backlogSlices = parseBacklogSlices(backlogText);
  const currentSlice = parseSliceBlockWithLists(currentSliceText);
  const backlogReady = backlogSlices.some(
    (slice) => sliceReadinessListsPresent(slice) && !sliceHasPlaceholderValues(slice),
  );
  const currentReady = sliceReadinessListsPresent(currentSlice) && !sliceHasPlaceholderValues(currentSlice);
  const singleScaffoldPattern = backlogSlices.length <= 1
    && normalizeWhitespace(backlogSlices[0]?.title || '') === normalizeWhitespace(currentSlice.title || '')
    && normalizeWhitespace(backlogSlices[0]?.objective || '') === normalizeWhitespace(currentSlice.objective || '');

  if (!backlogReady || !currentReady || singleScaffoldPattern) {
    issues.push(
      'backlog/current-slice appear scaffold-only; run pm:plan-slices to generate delivery-ready slices.',
    );
  }

  return issues;
}

function validate({ targetRoot, valuesPath }) {
  const manifest = loadManifest();
  const values = loadValues(valuesPath);
  verifyRequiredTokens(manifest, values);
  verifyTemplateTokens(manifest, values);

  const exemptions = new Set(manifest.drift_exemptions || []);
  const errors = [];

  for (const entry of manifest.source_of_truth || []) {
    if (exemptions.has(entry.target)) {
      continue;
    }

    const outPath = path.join(targetRoot, entry.target);
    if (!fs.existsSync(outPath)) {
      errors.push(`${entry.target}: missing generated file`);
      continue;
    }

    const actual = readText(outPath);
    const expected = expectedContent(entry, manifest, values, '1970-01-01T00:00:00.000Z');

    const normalizedActual = stripGeneratedAt(actual);
    const normalizedExpected = stripGeneratedAt(expected);

    if (!normalizedActual.includes('generated_from:')) {
      errors.push(`${entry.target}: missing generated header marker`);
      continue;
    }

    if (normalizedActual !== normalizedExpected) {
      const diffLine = firstDiffLine(normalizedActual, normalizedExpected);
      errors.push(`${entry.target}: drift detected (first difference at line ${diffLine})`);
    }
  }

  if (errors.length > 0) {
    console.error('fabric validate: FAILED');
    errors.forEach((e) => console.error(`- ${e}`));
    process.exit(1);
  }

  console.log('fabric validate: OK');
}

function doctor({ targetRoot, valuesPath }) {
  const manifest = loadManifest();
  const manifestPath = path.join(targetRoot, '.system/project-manifest.yaml');
  const currentSlicePath = path.join(targetRoot, 'docs/product/current-slice.yaml');
  const backlogPath = path.join(targetRoot, 'docs/product/backlog.yaml');

  const issues = [];

  if (!fs.existsSync(manifestPath)) {
    issues.push('missing .system/project-manifest.yaml');
  }
  if (!fs.existsSync(currentSlicePath)) {
    issues.push('missing docs/product/current-slice.yaml');
  }
  if (!fs.existsSync(backlogPath)) {
    issues.push('missing docs/product/backlog.yaml');
  }

  if (issues.length === 0) {
    const manifestText = readText(manifestPath);
    const currentSliceText = readText(currentSlicePath);
    const backlogText = readText(backlogPath);

    const statusBlock = parseStatusBlock(manifestText);
    const sliceBlock = parseSliceBlock(currentSliceText);

    const manifestSliceId = statusBlock.active_slice ?? null;
    const currentSliceId = sliceBlock.id ?? null;
    const currentSliceStatus = sliceBlock.status ?? null;

    if (manifestSliceId !== currentSliceId) {
      issues.push(
        `active_slice mismatch: manifest=${String(manifestSliceId)} current-slice=${String(currentSliceId)}`,
      );
    }

    if (currentSliceStatus === 'completed' && statusBlock.active_slice_state !== 'completed') {
      issues.push(
        `active_slice_state mismatch: expected completed when current slice is completed, got ${String(
          statusBlock.active_slice_state,
        )}`,
      );
    }

    const backlogStatus = parseBacklogSliceStatus(backlogText, currentSliceId);
    if (backlogStatus == null) {
      issues.push(`current slice ${String(currentSliceId)} not found in backlog`);
    } else if (backlogStatus !== currentSliceStatus) {
      issues.push(
        `slice status mismatch for ${currentSliceId}: backlog=${String(backlogStatus)} current-slice=${String(
          currentSliceStatus,
        )}`,
      );
    }

    issues.push(
      ...collectBootstrapSemanticIssues({
        targetRoot,
        valuesPath,
        manifestText,
        currentSliceText,
        backlogText,
      }),
    );
  }

  const dbConfig = manifest.db || {};
  for (const rel of dbConfig.required_files || []) {
    if (!fs.existsSync(path.join(targetRoot, rel))) {
      issues.push(`db readiness: missing ${rel}`);
    }
  }

  const envKeys = parseEnvKeys(path.join(targetRoot, '.env.example'));
  for (const key of dbConfig.required_env_keys || []) {
    if (!envKeys.has(key)) {
      issues.push(`db readiness: missing env key ${key} in .env.example`);
    }
  }

  if (issues.length > 0) {
    console.error('fabric doctor: FAILED');
    issues.forEach((i) => console.error(`- ${i}`));
    process.exit(1);
  }

  console.log('fabric doctor: OK');
}

function gate({ targetRoot, valuesPath }) {
  validate({ targetRoot, valuesPath });
  doctor({ targetRoot, valuesPath });
  console.log('fabric gate: OK');
}



function slugifySliceTitle(title) {
  return String(title || 'slice')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'slice';
}

function assertNoPlaceholdersInArtifact(relPath, text) {
  const placeholders = [...new Set(listAllPlaceholderMatches(text))];
  if (placeholders.length > 0) {
    throw new Error(`${relPath} still contains unresolved placeholders (${placeholders.join(', ')})`);
  }
}

function renderYamlList(indent, values) {
  if (!values || values.length === 0) {
    return [`${' '.repeat(indent)}[]`];
  }
  return values.map((value) => `${' '.repeat(indent)}- ${quoteYamlString(String(value))}`);
}

function renderCurrentSliceBody(slice, generatedAt) {
  const lines = [
    'schema_version: 1',
    `generated_at_utc: ${quoteYamlString(generatedAt)}`,
    'slice:',
    `  id: ${quoteYamlString(slice.id)}`,
    `  title: ${quoteYamlString(slice.title)}`,
    `  milestone: ${quoteYamlString(slice.milestone)}`,
    `  owner_role: ${quoteYamlString(slice.owner_role)}`,
    `  status: ${quoteYamlString(slice.status)}`,
    `  objective: ${quoteYamlString(slice.objective)}`,
    '  in_scope:',
    ...renderYamlList(4, slice.in_scope),
    '  out_of_scope:',
    ...renderYamlList(4, slice.out_of_scope),
    '  acceptance_criteria:',
    ...renderYamlList(4, slice.acceptance_criteria),
    '  dependencies:',
    ...renderYamlList(4, slice.dependencies),
    '  done_definition:',
    ...renderYamlList(4, slice.done_definition),
  ];
  return `${lines.join('\n')}\n`;
}

function renderBacklogBody(slices, generatedAt) {
  const lines = [
    'schema_version: 1',
    `generated_at_utc: ${quoteYamlString(generatedAt)}`,
    'backlog:',
    '  slices:',
  ];
  for (const slice of slices) {
    lines.push(`    - id: ${quoteYamlString(slice.id)}`);
    lines.push(`      title: ${quoteYamlString(slice.title)}`);
    lines.push(`      objective: ${quoteYamlString(slice.objective)}`);
    lines.push(`      status: ${quoteYamlString(slice.status)}`);
    lines.push(`      owner_role: ${quoteYamlString(slice.owner_role)}`);
    lines.push('      in_scope:');
    lines.push(...renderYamlList(8, slice.in_scope));
    lines.push('      out_of_scope:');
    lines.push(...renderYamlList(8, slice.out_of_scope));
    lines.push('      acceptance_criteria:');
    lines.push(...renderYamlList(8, slice.acceptance_criteria));
    lines.push('      dependencies:');
    lines.push(...renderYamlList(8, slice.dependencies));
    lines.push('      done_definition:');
    lines.push(...renderYamlList(8, slice.done_definition));
  }
  return `${lines.join('\n')}\n`;
}

function deriveImplementationTargets(slice) {
  const slug = slugifySliceTitle(slice.title);
  const scopeHints = String([slice.title, slice.objective, ...(slice.in_scope || [])].join(' ')).toLowerCase();
  const targets = [];
  if (scopeHints.includes('onboarding')) {
    targets.push('src/features/onboarding/');
    targets.push('src/features/profile/');
    targets.push('src/routes/onboarding*');
    targets.push('tests/onboarding/');
  } else {
    targets.push(`src/features/${slug}/`);
    targets.push(`src/routes/${slug}*`);
    targets.push(`tests/${slug}/`);
  }
  if (scopeHints.includes('persist') || scopeHints.includes('profile') || scopeHints.includes('data')) {
    targets.push('supabase/migrations/ (if schema change is required)');
  }
  return [...new Set(targets)];
}

function renderImplementationNotes({ slice, statusLabel, fileTargets, verificationSummary, nextSteps, generatedAt }) {
  const completedScope = statusLabel === 'Completed'
    ? (slice.in_scope || []).map((item) => `- ${item}`)
    : ['- Not closed yet. Use this section to track completed items during implementation.'];
  const contextLines = [
    ...((slice.dependencies || []).map((d) => `- ${d}`)),
    ...((slice.in_scope || []).map((d) => `- In scope: ${d}`)),
  ];
  const lines = [
    '# Current Slice Implementation Notes',
    '',
    `Date: \`${String(generatedAt).slice(0,10)}\``,
    `Slice: \`${slice.id} - ${slice.title}\``,
    `Status: \`${statusLabel}\``,
    '',
    '## 1. Handoff Context',
    ...(contextLines.length > 0 ? contextLines : ['- No additional handoff context recorded.']),
    '',
    '## 2. Slice Objective',
    '',
    `${slice.objective}`,
    '',
    '## 3. File and Module Targets',
    ...fileTargets.map((t) => `- ${t}`),
    '',
    '## 4. Completed Scope',
    ...completedScope,
    '',
    '## 5. Verification Evidence Summary',
    ...verificationSummary.map((v) => `- ${v}`),
    '',
    '## 6. Next Execution Steps',
    ...nextSteps.map((s, i) => `${i + 1}. ${s}`),
    '',
  ];
  return lines.join('\n');
}

function updateBacklogAndCurrentSliceForActive({ targetRoot, activeSlice, slices, generatedAt }) {
  const fabricManifest = loadManifest();
  const backlogPath = path.join(targetRoot, 'docs/product/backlog.yaml');
  const currentSlicePath = path.join(targetRoot, 'docs/product/current-slice.yaml');
  const backlogHeader = metadataHeader(
    'docs/product/backlog.yaml',
    'templates/backlog.template.yaml',
    fabricManifest.fabric_version,
    generatedAt,
  );
  const currentSliceHeader = metadataHeader(
    'docs/product/current-slice.yaml',
    'templates/current-slice.template.yaml',
    fabricManifest.fabric_version,
    generatedAt,
  );
  writeTextAtomic(backlogPath, `${backlogHeader}${renderBacklogBody(slices, generatedAt)}`);
  writeTextAtomic(currentSlicePath, `${currentSliceHeader}${renderCurrentSliceBody(activeSlice, generatedAt)}`);
}

function updateManifestActiveSliceState({ targetRoot, activeSlice, generatedAt, currentMode = 'delivery' }) {
  const manifestPath = path.join(targetRoot, '.system/project-manifest.yaml');
  let manifestText = readText(manifestPath);
  manifestText = setSectionScalar(manifestText, 'status', 'active_slice', quoteYamlString(activeSlice.id));
  manifestText = setSectionScalar(manifestText, 'status', 'active_slice_state', quoteYamlString(activeSlice.status));
  manifestText = setSectionScalar(manifestText, 'status', 'active_milestone', quoteYamlString(activeSlice.milestone));
  manifestText = setSectionScalar(manifestText, 'operating_model', 'current_mode', quoteYamlString(currentMode));
  manifestText = setTopLevelScalar(manifestText, 'last_updated_utc', quoteYamlString(generatedAt));
  if (!manifestText.endsWith('\n')) {
    manifestText = `${manifestText}\n`;
  }
  writeTextAtomic(manifestPath, manifestText);
}

function coderPrepareCurrentSlice({ targetRoot, valuesPath }) {
  const currentSlicePath = path.join(targetRoot, 'docs/product/current-slice.yaml');
  const baselinePath = path.join(targetRoot, 'docs/architecture/baseline.md');
  const uxPath = path.join(targetRoot, 'docs/ux/current-slice-flow.md');
  const implementationNotesPath = path.join(targetRoot, 'docs/implementation/current-slice-notes.md');
  if (!fs.existsSync(currentSlicePath)) {
    throw new Error('Cannot run coder:prepare-current-slice: missing docs/product/current-slice.yaml');
  }
  if (!fs.existsSync(baselinePath)) {
    throw new Error('Cannot run coder:prepare-current-slice: missing docs/architecture/baseline.md');
  }
  if (!fs.existsSync(uxPath)) {
    throw new Error('Cannot run coder:prepare-current-slice: missing docs/ux/current-slice-flow.md');
  }
  const currentSlice = parseSliceBlockWithLists(readText(currentSlicePath));
  assertNoPlaceholdersInArtifact('docs/architecture/baseline.md', readText(baselinePath));
  assertNoPlaceholdersInArtifact('docs/ux/current-slice-flow.md', readText(uxPath));
  const fileTargets = deriveImplementationTargets(currentSlice);
  const generatedAt = new Date().toISOString();
  const fabricManifest = loadManifest();
  const implHeader = metadataHeader(
    'docs/implementation/current-slice-notes.md',
    'templates/implementation-notes-template.md',
    fabricManifest.fabric_version,
    generatedAt,
  );
  const notesBody = renderImplementationNotes({
    slice: currentSlice,
    statusLabel: 'In progress',
    fileTargets,
    verificationSummary: [
      'Implementation preparation completed; coding can begin against the active slice contract.',
      'Architecture baseline and UX flow are both finalized and placeholder-free.',
    ],
    nextSteps: [
      'Implement the slice against the file/module targets above.',
      'Record any scope deviations before closeout.',
      'Run validate/doctor/gate before closing the slice.',
    ],
    generatedAt,
  });
  writeTextAtomic(implementationNotesPath, `${implHeader}${notesBody}`);

  const backlogPath = path.join(targetRoot, 'docs/product/backlog.yaml');
  const slices = parseBacklogSlices(readText(backlogPath));
  const updatedSlices = slices.map((slice) => slice.id === currentSlice.id ? { ...slice, status: 'in_progress' } : slice);
  const activeSlice = { ...currentSlice, status: 'in_progress', milestone: `${currentSlice.id}_implementation` };
  updateBacklogAndCurrentSliceForActive({ targetRoot, activeSlice, slices: updatedSlices, generatedAt });
  updateManifestActiveSliceState({ targetRoot, activeSlice, generatedAt });

  console.log('fabric coder:prepare-current-slice: OK');
  console.log(`- scope: ${activeSlice.id} ${activeSlice.title}`);
  console.log('- wrote: docs/implementation/current-slice-notes.md');
  console.log(`- file/module targets: ${String(fileTargets.length)}`);
  console.log('- current slice status: in_progress');
}

function coderCloseCurrentSlice({ targetRoot, valuesPath }) {
  const currentSlicePath = path.join(targetRoot, 'docs/product/current-slice.yaml');
  const baselinePath = path.join(targetRoot, 'docs/architecture/baseline.md');
  const uxPath = path.join(targetRoot, 'docs/ux/current-slice-flow.md');
  const implementationNotesPath = path.join(targetRoot, 'docs/implementation/current-slice-notes.md');
  const backlogPath = path.join(targetRoot, 'docs/product/backlog.yaml');
  if (!fs.existsSync(currentSlicePath) || !fs.existsSync(backlogPath)) {
    throw new Error('Cannot run coder:close-current-slice: missing current-slice or backlog artifact');
  }
  const currentSlice = parseSliceBlockWithLists(readText(currentSlicePath));
  const issues = [];
  if (!Array.isArray(currentSlice.acceptance_criteria) || currentSlice.acceptance_criteria.length === 0) {
    issues.push('current slice has no acceptance criteria');
  }
  if (!fs.existsSync(implementationNotesPath)) {
    issues.push('missing docs/implementation/current-slice-notes.md; run coder:prepare-current-slice first');
  }
  for (const [rel, p] of [
    ['docs/architecture/baseline.md', baselinePath],
    ['docs/ux/current-slice-flow.md', uxPath],
    ['docs/implementation/current-slice-notes.md', implementationNotesPath],
  ]) {
    if (!fs.existsSync(p)) {
      issues.push(`missing ${rel}`);
      continue;
    }
    const placeholders = [...new Set(listAllPlaceholderMatches(readText(p)))];
    if (placeholders.length > 0) {
      issues.push(`${rel} still contains unresolved placeholders (${placeholders.join(', ')})`);
    }
  }
  if (issues.length > 0) {
    console.error('fabric coder:close-current-slice: FAILED');
    issues.forEach((i) => console.error(`- ${i}`));
    process.exit(1);
  }
  const fileTargets = deriveImplementationTargets(currentSlice);
  const generatedAt = new Date().toISOString();
  const fabricManifest = loadManifest();
  const implHeader = metadataHeader(
    'docs/implementation/current-slice-notes.md',
    'templates/implementation-notes-template.md',
    fabricManifest.fabric_version,
    generatedAt,
  );
  const notesBody = renderImplementationNotes({
    slice: currentSlice,
    statusLabel: 'Completed',
    fileTargets,
    verificationSummary: [
      'Acceptance criteria were present and treated as satisfied for closeout.',
      'Architecture baseline, UX flow, and implementation notes are all placeholder-free.',
      'Run fabric gate after closeout to verify overall coherence.',
    ],
    nextSteps: [
      'Run orchestrator:advance-slice to activate the next slice.',
      'Keep implementation notes as the record for this completed slice.',
      'Issue a customer checkpoint when a customer-facing milestone exists.',
    ],
    generatedAt,
  });
  writeTextAtomic(implementationNotesPath, `${implHeader}${notesBody}`);

  const slices = parseBacklogSlices(readText(backlogPath));
  const updatedSlices = slices.map((slice) => slice.id === currentSlice.id ? { ...slice, status: 'completed' } : slice);
  const completedSlice = { ...currentSlice, status: 'completed', milestone: `${currentSlice.id}_closeout` };
  updateBacklogAndCurrentSliceForActive({ targetRoot, activeSlice: completedSlice, slices: updatedSlices, generatedAt });
  updateManifestActiveSliceState({ targetRoot, activeSlice: completedSlice, generatedAt });

  console.log('fabric coder:close-current-slice: OK');
  console.log(`- closed slice: ${completedSlice.id} ${completedSlice.title}`);
  console.log('- updated: docs/implementation/current-slice-notes.md');
  console.log('- current slice status: completed');
}

function orchestratorAdvanceSlice({ targetRoot, valuesPath }) {
  const currentSlicePath = path.join(targetRoot, 'docs/product/current-slice.yaml');
  const backlogPath = path.join(targetRoot, 'docs/product/backlog.yaml');
  if (!fs.existsSync(currentSlicePath) || !fs.existsSync(backlogPath)) {
    throw new Error('Cannot run orchestrator:advance-slice: missing current-slice or backlog artifact');
  }
  const currentSlice = parseSliceBlockWithLists(readText(currentSlicePath));
  if (String(currentSlice.status || '').toLowerCase() !== 'completed') {
    throw new Error('Cannot run orchestrator:advance-slice: current slice is not completed. Run coder:close-current-slice first.');
  }
  const slices = parseBacklogSlices(readText(backlogPath));
  const currentIndex = slices.findIndex((slice) => slice.id === currentSlice.id);
  if (currentIndex === -1) {
    throw new Error('Cannot run orchestrator:advance-slice: active slice not found in backlog');
  }
  const nextSlice = slices.slice(currentIndex + 1).find((slice) => String(slice.status || '').toLowerCase() !== 'completed');
  if (!nextSlice) {
    console.log('fabric orchestrator:advance-slice: OK');
    console.log('- no remaining slices to activate');
    console.log('- backlog is complete or has no next actionable slice');
    return;
  }
  const generatedAt = new Date().toISOString();
  const activatedSlice = { ...nextSlice, status: 'planned', milestone: nextSlice.milestone || `${nextSlice.id}_delivery` };
  const updatedSlices = slices.map((slice) => {
    if (slice.id === activatedSlice.id) {
      return { ...slice, status: 'planned', milestone: activatedSlice.milestone };
    }
    return slice;
  });
  updateBacklogAndCurrentSliceForActive({ targetRoot, activeSlice: activatedSlice, slices: updatedSlices, generatedAt });
  updateManifestActiveSliceState({ targetRoot, activeSlice: activatedSlice, generatedAt });
  console.log('fabric orchestrator:advance-slice: OK');
  console.log(`- previous slice: ${currentSlice.id} ${currentSlice.title} (completed)`);
  console.log(`- activated next slice: ${activatedSlice.id} ${activatedSlice.title} (${activatedSlice.status})`);
  console.log('- current-slice and manifest updated cleanly');
}

export {
  initFactory,
  formatFromBrief,
  instantiate,
  execute,
  validate,
  doctor,
  gate,
  dbInit,
  dbCheck,
  dbReset,
  dbSeed,
  coderPrepareCurrentSlice,
  coderCloseCurrentSlice,
  orchestratorAdvanceSlice,
};
